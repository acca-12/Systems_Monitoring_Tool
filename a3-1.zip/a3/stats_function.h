#include <stdio.h>
#include <utmp.h>
#include <sys/utsname.h>
#include <string.h>
#include <ctype.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <sys/sysinfo.h>
#include <stdbool.h>
#include <limits.h>
#include <sys/wait.h>
#define MAX_LINE 1024

#ifndef STATS_FUNCTION_H_   /* Include guard */
#define STATS_FUNCTION_H_


bool checkIfStringIsNumber(char *string);

void header(int samples, int interval);

void printGraphics(int iteration, float array[][4]);

void printSystem(int iteration, float array[][4], int* fd);

void cpuInfo(int iteration, float array[][3], int* fd);

void printUser(int *fd);

void printLogistics();

long int memoryUsage();

#endif