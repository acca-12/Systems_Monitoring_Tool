
#include "stats_function.h"
#include <signal.h>
#define MAX_LINE 1024






void printLogistics(){
    /*
        @brief: Prints the logistics of the system, inlcuding system name, machine name, version, release, and architecture
    */

    //intialize utsname struct to use uname
    struct utsname h;
    //uname sets the proper system information fields in parameter's address
    uname(&h);
    printf("### System Information ###\n");
    printf(" System Name = %s\n", h.sysname);
    printf(" Machine Name = %s\n", h.nodename);
    printf(" Version = %s\n", h.version);
    printf(" Release = %s\n", h.release);
    printf(" Architecture = %s\n", h.machine);
    printf("---------------------------------------\n");

}

void printMemoryUsage(long int usage){

    //prints memory usage
    printf(" Memory Usage: %ld KB\n", usage);
    printf("---------------------------------------\n");
}

 
void handler_ctrlc(int signal){
    //this function handles ctrl c and makes sure to check all the child processes have exited before killing parent


    char choice;
    int all_children_exit_properly = 1;
    int status;
    do{
        printf("Are you sure you want to quit the program [Y/N]? ");
        scanf(" %c", &choice);
    }while(choice != 'Y' &&  choice != 'y' &&  choice != 'n' && choice != 'N');
    if(choice == 'Y' || choice == 'y'){
        while(wait(&status) > 0){
            if(!WIFEXITED(status))
                all_children_exit_properly = 0;
        } //make sure so child processes
        if(all_children_exit_properly)
            exit(EXIT_SUCCESS);
        fprintf(stderr, "Child did not exit properly");
        exit(EXIT_FAILURE);
    }
}

void handler_ctrlz(int signal){
    //ignore
    return;
}

void printMemoryBars(float relative_change){
    //this function prints the bars given the realtiove change with a 0.01 increment (this can be easily toggled)
   float copy = relative_change;
   if(relative_change < 0){
       relative_change *= -1;
       for(float i = 0; i < relative_change; i+= 0.01){
           printf("#");
       }
       printf("@ ");
   }else{
       for(float i = 0; i < relative_change; i+= 0.01){
           printf("#");
       }
       printf("* ");
   }
   printf("(%.2f)\n", copy);
}

void printCpuBars(float percentage){

    //this function prints the bars given the percentage with a 1 percent increment 
    printf("    ");
    for(int i = 0; i < percentage; i++){
        printf("|");
    }
       printf("%.2f\n", percentage);
}

void addUserMem(long int *mem, int *fd){
    //this function adds the memory usage for the forked user process
    char line[MAX_LINE];  
    ssize_t bytes_read;
    bytes_read = read(fd[0], line, sizeof(line));
    
        if (bytes_read == -1) {
            perror("read");
            exit(EXIT_FAILURE);
        } else if (bytes_read > 0) {
            *mem += strtol(line, NULL, 10);
    }
}




void printUserInfo(int* fd){
    // this function prints user information through reading the pipe
    char line[MAX_LINE];
    printf("### Sessions/Users ### \n");
    ssize_t bytes_read;

    do {
        bytes_read = read(fd[0], line, sizeof(line));
        if (bytes_read == -1) {
            perror("read");
            exit(EXIT_FAILURE);
        } else if (bytes_read > 0) {
            printf("%s\n", line);
        }
    } while (bytes_read > 0);
    
}


void printMemoryInfo(int sequential, int graphics, float array[][4], int iteration, int samples){
    //this function prints the memory info at a given iteration with sequential or graphic options 
    float physical_used = array[iteration][0];
    float total_physical = array[iteration][1];
    float virtual_used = array[iteration][2];
   float total_virtual = array[iteration][3];
   float relative_change = 0;
   if(iteration != 0){
       relative_change = array[iteration][2] - array[(iteration - 1)][2];
   }

   printf("### Memory ### (Phys.Used/Tot -- Virtual Used/Tot)\n");
   if(sequential){
       //if sequential print blank lines except at int iteration. At int iteration print calculated values.
       for(int i = 0; i < samples; i++){
           if(i != iteration){
               printf("\n");
           }else{
               if(!graphics)
                   printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB \n", physical_used, total_physical, virtual_used, total_virtual);
               else{
                   printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB      |", physical_used, total_physical, virtual_used, total_virtual);
                   printMemoryBars(relative_change);
               }
           }
       }
   }else{
       //if not sequential print old values from float *array (this is a 2D array) until int iteration. At int iteration print calculated values.
       for(int i = 0; i < iteration + 1; i++){
           if(i != iteration){
               if(!graphics){
                   printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB \n", array[i] [0], array[i][1], array[i][2], array[i][3]);
               }else{
                   float previous_change = 0;
                   if(i != 0){
                       previous_change = array[(i)][2] - array[(i - 1)][2];
                    }
                    printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB    |", array[i] [0], array[i][1], array[i][2], array[i][3]);
                    printMemoryBars(previous_change);
               }
           }else{
               if(!graphics){
                    //graphical option to print the bars very cool
                   printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB \n", physical_used, total_physical, virtual_used, total_virtual);
               }else{
                   printf("%.2f GB / %.2f GB -- %.2f GB / %.2f GB    |", physical_used, total_physical, virtual_used, total_virtual);
                   printMemoryBars(relative_change);
               }
           }
       }
       //print new line for the rest
       for(int i = iteration + 1; i < samples; i++){
           printf("\n");
       }

   }
   printf("---------------------------------------\n");
}


void printCpuInfo(int sequential, int graphics, float array[][3], int iteration, int cpus, int samples){
        //print the cpu infromation given the iteration with sequential and graphical options
        float percentage = array[iteration][2];
        printf("---------------------------------------\n");
        printf("CPU cores: %d\n",  cpus);
        printf("CPU usage : %.2f%%\n", percentage);
        printf("---------------------------------------\n");
        if(graphics){
            if(sequential){
                for(int i = 1; i < iteration + 1; i++){
                    if(i != iteration){
                     printf("\n");
                    }else{
                     printCpuBars(percentage);
                    }
                }
            }else{
                for(int i = 1; i < iteration + 1; i++){
                    printCpuBars(array[i][2]);
                }
            }
        }
}







int main(int argc, char **argv){
    /*
        @brief: Handles flags and based on flags turned on, call the appropiate functions to display the desired information
        @param: int argc: the number of arguments(flags) specified by user, including execution file
                char **argv: pointer to a pointer of character arrays (array of strings) that represents the flags specified by user
    */

    //default settings without any flags
    int samples = 10;
    int time = 1;
    int user = 1;
    int systemShow = 1;
    int sequential = 0;
    int numInts = 0;
    int setTime = 0;
    int setSamples = 0;
    int graphics = 0;

    
    //if there are more than 1 argument then there are flags, check what user inputted
    if(argc > 1){
        for(int i = 1; i < argc; i++){
            //if only wants to show user information then we turn off systemShow
            if(strcmp(argv[i], "--user") == 0){
                systemShow  = 0;
            //if only wants to show system infomration then we turn off user
            }else if(strcmp(argv[i], "--system") == 0){
                user = 0;
            //if sequential flag called, then we turn it on
            }else if(strcmp(argv[i], "--graphics") == 0){
                graphics = 1;
            }else if(strcmp(argv[i], "--sequential") == 0){
                sequential = 1;
            //if the first 10 characters of the flag matches --samples= and then 11 isnt a null character. then check the characters after =
            }else if((strncmp(argv[i], "--samples=",10) == 0) && argv[i][10] != '\0'){
                char *traverse = argv[i];
                //jump to 10th index
                traverse = traverse + (10 * sizeof(char));
                //check if each character is a number
                if(checkIfStringIsNumber(traverse)){
                    //set samples
                    samples = atoi(traverse);
                }else{
                    //invalid flag, doesn't contain all numbers after =
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                //if this reaches, then valid and we can confirm --samples=X was a flag
                setSamples = 1;
            //same logic as samples, but with time
            }else if((strncmp(argv[i], "--tdelay=",9) == 0) && argv[i][9] != '\0'){
                char *traverse = argv[i];
                traverse = traverse + (9 * sizeof(char));
                if(checkIfStringIsNumber(traverse)){
                    time = atoi(traverse);
                }else{
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                //if this reaches, then valid and we can confirm --time=X was a flag
                setTime = 1;
            //checks if the first character of flag is a number, this is for the positional arguments
            }else if((isdigit(*argv[i])) && numInts == 0){
                char *traverse = argv[i];
                //checks if all characters are numbers, if all numbers, set to samples, otherwise error
                if(checkIfStringIsNumber(traverse)){
                    samples = atoi(traverse);
                }else{
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                //increment the number of integers and number of integers in sequence
                numInts++;
            //Also for positional argument. Since numInts default is 0, this won't run until the previous elseif implying at least 3 arguments, meaning you can check the previous.
            }else if(isdigit(*argv[i]) && isdigit(*argv[i-1]) && numInts == 1){
                char *traverse = argv[i];
                //checks if all characters are numbers, if all numbers, set to time, otherwise error
                if (checkIfStringIsNumber(traverse)){
                    time = atoi(traverse);
                }else{
                    fprintf(stderr, "%s", "Invalid flag\n");
                    exit(EXIT_FAILURE);
                }
                //increments numInts and integerSequence
                numInts++;
            //any other flag is invalid
            }else{
                fprintf(stderr, "%s", "Invalid flag\n");
                exit(EXIT_FAILURE);
            }


        } 
        //if only one positional argument and samples has been set, then invalid
        if(numInts == 1 && (setSamples)){
                fprintf(stderr, "%s", "Invalid flag\n");
                exit(EXIT_FAILURE);
        }
        //if both positional arguments, and set time or sample, invalid
        if(numInts == 2 && (setSamples || setTime)){
                fprintf(stderr, "%s", "Invalid flag\n");
                exit(EXIT_FAILURE);
        }
        //typing both --user and --system is equivalent to normal, so invalid
        if(systemShow == 0 && user == 0){
                fprintf(stderr, "%s", "Showing user and system can be called normally\n");
                exit(EXIT_FAILURE);
        }
    }
       //creating arrays to keep track of values
        int x = samples + 1;
        float arr[samples][4];
        float cpu_arr[x][3];
        //let first samples = 0
        cpu_arr[0][0] = 0;
        //special buffer for when we read/write
        char buffer[100];
        int pid;
        //creating sigaction to handle signals
        struct sigaction newact_ctrlc;
        newact_ctrlc.sa_handler = handler_ctrlc;
        newact_ctrlc.sa_flags = 0;

        struct sigaction newact_ctrlz;
        newact_ctrlz.sa_handler = handler_ctrlz;
        newact_ctrlz.sa_flags = 0;

    
        sigaction(SIGINT, &newact_ctrlc, NULL);
        sigaction(SIGTSTP, &newact_ctrlz, NULL);
        //special pipes, each pipe reads and writes from one function
        int pipefd[2];
        int pipefe[2];
        int pipeff[2];
        //check if we want to fork
        int check_values[3] = {0, 0, 0};
        if(systemShow){
            check_values[0] = 1;
            check_values[2] = 1;
        }
        if(user){
            
            check_values[1] = 1;
         } 
        for(int i = 0; i < samples; i++){
            int all_children_exit_properly = 1;
            int status;

            //error checking and piping
            if(pipe(pipefd) == -1){
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if(pipe(pipefe) == -1){
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if(pipe(pipeff) == -1){
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            for(int j = 0; j < 3; j++){
                //checks if can fork
               if(check_values[j]){ 
                if((pid= fork()) == 0){
                    // j = 0 system is forked, j = 1 user forked, j= 2 cpu forked, more error chgecking
                    if(j == 0){
                        if(close(pipefd[0]) == -1){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if(close(pipefe[0] == -1)){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if(close(pipefe[1]) == -1){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if(close(pipeff[0]) == -1){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if(close(pipeff[1]) == -1){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        printSystem(i, arr, pipefd);
                        
                        if(close(pipefd[1])){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        exit(EXIT_SUCCESS);
                    }
                    if(j == 1){
                        if (close(pipefe[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefd[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefd[1]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipeff[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipeff[1]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        printUser(pipefe);
                        if(close(pipefe[1])){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        exit(EXIT_SUCCESS);
                    }
                    if(j == 2){
                        if (close(pipeff[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefd[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefd[1]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefe[0]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        if (close(pipefe[1]) == -1) {
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        cpuInfo(i + 1, cpu_arr, pipeff);
                        if(close(pipeff[1]) == -1){
                            perror("pipe");
                            exit(EXIT_FAILURE);
                        }
                        exit(EXIT_SUCCESS);
                    }
                }
                //failed fork
                if(pid == -1){
                    perror("fork");
                    while(wait(&status) > 0);
                    exit(EXIT_FAILURE);
                } 
              }
            }
            //close parent writes dont need
            if (close(pipefd[1]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if (close(pipefe[1]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if (close(pipeff[1]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            //wait for all children
            while(wait(&status) > 0){
            if(!WIFEXITED(status))
                all_children_exit_properly = 0;
            } //make sure so child processes
            if(!all_children_exit_properly){
                fprintf(stderr, "Child did not terminate properly, ending...");
                exit(EXIT_FAILURE);
            }
            //special contrived values that i have created to properly gather info
            int index_1 = -1;
            int index_2 = -2;
            int cpus = 0;
            long int total_memory_usage = memoryUsage();

            ssize_t bytes_read_mem;
            ssize_t bytes_read_cpu;
            //reads if no read avaialbe then end of file
            do {
                bytes_read_mem = read(pipefd[0], buffer, sizeof(buffer));
                if (bytes_read_mem == -1) {
                     perror("read");
                     exit(EXIT_FAILURE);
                } else if (bytes_read_mem > 0) {
                        if(index_1 == -1){
                           
                            long int x = strtol(buffer, NULL, 10);
                            total_memory_usage += x;
                            
                        }else{                
                            arr[i][index_1] = strtod(buffer, NULL);
                        }
                
                        index_1++;
                    }
                } while (bytes_read_mem > 0);

        
            do {
                bytes_read_cpu = read(pipeff[0], buffer, sizeof(buffer));
                if (bytes_read_cpu == -1) {
                    perror("read");
                    exit(EXIT_FAILURE);
                } else if (bytes_read_cpu > 0) {
                        if(index_2 == -2){
                           
                            long int x = strtol(buffer, NULL, 10);
                            total_memory_usage +=x;
                        
                        }else if(index_2 == -1)
                            cpus = strtol(buffer, NULL, 10);
                        else
                            cpu_arr[i+1][index_2] = strtod(buffer, NULL);
                        index_2++;
                }
            } while (bytes_read_cpu > 0);
            //want to clear everything and reprint if not sequential
            if(!sequential)
                printf("\e[H\e[2J\e[3J");
            else
                printf(" >>> iteration: %d\n", i);
            if(user){
                addUserMem(&total_memory_usage, pipefe);
            }
            printMemoryUsage(total_memory_usage);
            if(systemShow){
                printMemoryInfo(sequential, graphics, arr, i, samples);
            }
            if(user)
               printUserInfo(pipefe);
            if(systemShow)
                printCpuInfo(sequential, graphics, cpu_arr, i + 1, cpus, samples);
            //closing all parent, it will re pipe anyways, everything is closed !
            if (close(pipefd[0]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if (close(pipefe[0]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            if (close(pipeff[0]) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            sleep(time);
        }
        
        printLogistics();


}