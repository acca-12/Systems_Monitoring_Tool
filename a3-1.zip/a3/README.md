# CSCB09 Assignement 3 #

## The Problem ##
For this assignment, we were tasked to make the system monitoring tool in A1 concurrent. Achieving this is quite straight forward but first
I will talk about the challenges I faced. I first tried to implement A3 the same as A1 but by forking three times, setting up the pipes and reading. That is, I was sampling in the child processes. However, I quickly faced the issue of read being blocked. Because read was blocked, my output would print all at once at the very end. I could have mitigated this problem by delaying in the child process as soon as it was forked but this could result in timing issues. So, I took a different approach. I sampled in the main and for each sample, I forked the amount of processes required and WAITED for all the children to finish their sampling before continuing in main. This way I can ensure that there is no timing issue. Since I implemented A1 with an array, this was quite easily done. To get previous information I can simply access array at index i - 1 because forking copies the process control block, meaning the arrays values are saved at each iteration. After I finish sampling in the child processes, I wrote into the pipe, and since the parent is is also piped and their write and read are connected, I can achieve inter-process communication. After the sampling, is finished I simply read the information provided by our child processes and then print them out accordingly. 

## Signal handling ##
Another part of this assignment was to handle Ctrl + Z and Ctrl + C differently. For the former we are meant to ignore, and the latter we  are meant to prompt the user wether they truly want to quit the program. This was achieved by setting up handler functions that were appropiate for the purpose and using sigaction to handle the signals. It is important to note that pressing Ctrl + Z and Ctrl + C during a sleep results in the meant time interval to be lost. Apparently, fixing this issue is outside the scope of this course, so I will instead provide an explanation of this phenomenon. We recall that sleep() is INTERRUPTIBLE by other signals this means that the OS simply wakes the program back up resulting in this phenomenon. 

### Functions ###

These are basically the same as a1, but with read and write within them. So I will list the modified functions,


This function is called when the user has specified system and is one of the concurrent functions. As we can see it takes the iteration, array, and filedescriptor array as parameters. The first two is to be able to sample. The last is so we know where to write.

void printSystem(int iteration, float array[][4], int* fd);

This function is called when the user has specified system and is one of the concurrent functions. As we can see it takes the iteration, array, and filedescriptor array as parameters. The first two is to be able to sample. The last is so we know where to write.

void cpuInfo(int iteration, float array[][3], int* fd);

This function is called when the user has specified user and is one of the concurrent functions. As we can see it takes the fd as an argument so that we know where to write

void printUser(int *fd);

Since each child process is its own program we should calculate its memory usage and add it up to the parent. This function serves that exact purpose.

long int memoryUsage();


## How to run the program ##
The flags from a1 are still valid. Any other flag is invalid however.
In the terminal...
	
	Go to directory where stats_function.c stats_function.h a3_main.c makefile are in
	
	make a2
	
	/a2 flags
	
	where -flags are a combination of any of the flags described in the assignment description
	with a few exceptions