#include "stats_function.h"


bool checkIfStringIsNumber(char *string){
    /* 
        @brief: checks if char *string is a number 
        @param: char* to a string
        @return: return true iff every character in char* (up to null) is a number
    */


    //goes until delimeter is reached '\0' has value 0
    while(*string){
        //first occurence of non numeric character will return false
        if(!isdigit(*string)){
            return false;
        }
        //goes to next character
        string = string + sizeof(char);
    }
    //code will only reach this if every character is indeed a digit
    return true;
}





long int memoryUsage(){
        struct rusage x;
        //specfying the who to be the program and will set rumaxrss appropiately
        getrusage(RUSAGE_SELF, &x);
        return x.ru_maxrss;
} 


void printSystem(int iteration, float array[][4], int *fd){
   /*
       @brief: Calculates and prints the used and total physical/virtual memory.
       @param: int iteration: the iteration out of samples the program is currently on. int samples: the number of samples specified by user.
               float *array: used to store and retrieve used and total physical/vritual memory values. int sequential: if user wants sequential, then different print process.
      
       Explanation of printing:
       If sequential is 1 then the program prints newlines until the int iteration, where it will print the physical/virtual memory usage and total,
       and then proceeds to print newlines until int samples - 1
       If sequential is 0 then the program will print the physical/virtual memory usage and total retrieved from *array until int iteration where it will calculate
       and then print the iteraton's memory usage. From iteration + 1 to samples - 1 inclusive, it will print new lines.


   */
   long int usage = memoryUsage();
   struct sysinfo memories;
   //Intializes the struct with appropiate values to be able to use
   sysinfo(&memories);
   //Calculates the memory fields in GB (documentation has the fields of struct in bytes). Conversion used: 10 ^ 9 bytes = 1 GB
   float free_physical = memories.freeram/(pow(1024, 3));
   float  free_swap = memories.freeswap/(pow(1024, 3));
   float  total_physical= memories.totalram/(pow(1024, 3));
   float  total_swap = memories.totalswap/(pow(1024, 3));
   //Calculates the following memory totals based on piazza post recommendations
   float total_virtual = total_physical + total_swap;
   float physical_used = total_physical - free_physical;
   float virtual_used = total_virtual - free_physical - free_swap;


   //saves values in array to be used for future iterations



   char str[100];
   sprintf(str, "%ld", usage);
   if (write(fd[1], str, sizeof(str)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }
   sprintf(str, "%f", physical_used);
   if (write(fd[1], str, sizeof(str)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }
   sprintf(str, "%f", total_physical);
   if (write(fd[1], str, sizeof(str)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }
   sprintf(str, "%f", virtual_used);
   if (write(fd[1], str, sizeof(str)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }
   sprintf(str, "%f", total_virtual);
   if (write(fd[1], str, sizeof(str)) == -1) {
        perror("write");
        exit(EXIT_FAILURE);
    }

}

void cpuInfo(int iteration, float array[][3], int *fd){
   /*
       @brief: Calculates change in CPU usage based on the long int previous summation of cpu times excluding idle time.
       @param: long int previous: this is the saved previous value of the previous iteration. This is helpful in finding the percentage use.
               int i: this specifes what iteration program is on.
      


       If int i = -1, then this is baseline iteration and it will only return the summation without printing the percetange use
       If int i != -1, then calculate cpu times without idle and take its absolute difference with long int previous and divide by the latter and multiply by 100
       to calculate and print percentage use relative to last iteration (OH recommendation).
      
       @return: return a long int which is the calculated summation of times (without idle), so it can be used for next iteration.
   */

   //opens file /proc/stat where the CPU time usages can be read
   FILE *f = fopen("/proc/stat", "r");
   char cpu[255];
   long int total_cpu_util = 0;
   long int cpu_util_instance = 0;
   long int user = 0;
   long int nice = 0;
   long int system = 0;
   long int idle = 0;
   long int iowait = 0;
   long int irq = 0;
   long int softirq = 0;
   long int steal = 0;
   long int guest = 0;
   float percentage = 0;

   if(f != NULL){
        char str[100];
        fscanf(f, "%s %ld %ld %ld %ld %ld %ld %ld %ld %ld", cpu, &user, &nice, &system, &idle, &iowait, &irq,
                                                        &softirq, &steal, &guest);
        total_cpu_util = user + nice + system + idle + iowait + irq;
        cpu_util_instance = total_cpu_util - idle;
        percentage = fabs((cpu_util_instance - array[(iteration - 1)][0])/(total_cpu_util - array[(iteration - 1)][1]) * 100);
        
        long int usage = memoryUsage();
        sprintf(str, "%ld", usage);
        if (write(fd[1], str, sizeof(str)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        sprintf(str, "%d", get_nprocs_conf());
        if (write(fd[1], str, sizeof(str)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        sprintf(str, "%ld", cpu_util_instance);
        if (write(fd[1], str, sizeof(str)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        sprintf(str, "%ld", total_cpu_util);
        if (write(fd[1], str, sizeof(str)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        sprintf(str, "%f", percentage);
        if (write(fd[1], str, sizeof(str)) == -1) {
            perror("write");
            exit(EXIT_FAILURE);
        }
        
        
   }else{
       //if file doesn't open, print error message
       fprintf(stderr, "%s", "CPU info cannot be displayed");
       
       exit(EXIT_FAILURE);
   }
   if(fclose(f)){
       //if file doesn't close, print error
       fprintf(stderr, "%s", "Failed closing file");
       
       exit(EXIT_FAILURE);
   }
   //return total_noIdle so it can be used for the next iteration.
}

void printUser(int* fd){
    /*
        @brief: Prints the users and sessions currently logged into the system using utmp
    */
    
    
    char line[MAX_LINE];
    //intialize a struct utmp pointer to be able to read utmp file
    long int x = memoryUsage();
    sprintf(line, "%ld", x);
    if (write(fd[1], line, sizeof(line)) == -1) {
                    perror("write");
                    exit(EXIT_FAILURE);
    }
    struct utmp* users;
    //rewinds the file pointer to beginning of utmp file
    setutent();
    //reads a line from current position in utmp file. returns a pointer to a structure containing fields of the line
    users = getutent();
    //while it reads an appropiate utmp file then continue
    while(users){
        //if type is user process (normal process), then print appropiate struct fields
        if(users->ut_type == USER_PROCESS){
                 snprintf(line, MAX_LINE, " %s       %s %s\n", users->ut_user, users->ut_line, users->ut_host);
                 if (write(fd[1], line, sizeof(line)) == -1) {
                    perror("write");
                    exit(EXIT_FAILURE);
                }
        }
        users = getutent();
    }
}





